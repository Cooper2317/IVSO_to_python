
%+++ Example

load('corn moisture.mat')

F=ivso(Xcal,ycal,10,10,'autoscaling',8000);

[RMSEP,RMSEF]=predict(Xcal,ycal,Xtest,ytest,F.Select_variables,10,10,'autoscaling')


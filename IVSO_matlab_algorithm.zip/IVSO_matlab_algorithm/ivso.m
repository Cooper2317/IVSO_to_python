
function F=IVSO(Xcal,ycal,A_max,fold,method,num_bms)
%     IVSO: Iteratively variable subset optimization
%+++  Input:  Xcal: m x n  (Sample matrix)
%            ycal: m x 1  (measured property)
%            A_max: The max PC for cross-validation
%            fold: The group number for cross validation. when fold = m, it is leave-one-out CV
%            method: Pretreatment method. Contains: autoscaling, center etc.
%            num_bms: The number of sampling runs by WBMS
%            
%+++ Weiting Wang, March. 25, 2015, wang_weiting@foxmail.com
%+++ Advisor: Yizeng Liang, yizeng_liang@263.net

%++++Ref:  Weiting Wang, Yonghuan Yun, Baichuan Deng, Yizeng Liang, Wei Fan, A novel method that iteratively optimizes variable subset for variable selection in multivariate calibration     
                

%        Initial settings
if nargin<6; num_bms=5000;end;
if nargin<5; method='autoscaling';end;
if nargin<4; fold=10;end;
if nargin<3; A_max=10;end

tic;  
 [~,Nx]=size(Xcal);
 times=50;
Weight=zeros(times,Nx);
weight=ones(1,Nx);
Ranking=zeros(times,Nx);

%%%%%% main loop
 for iter=1:times
     
 %%%%%%  generate the binary matrix for sampling by WBMS
  V_binary_matrix=zeros(num_bms,Nx);
    for k=1:Nx
        column=[ones(round(weight(k)*num_bms),1);zeros(num_bms-round(weight(k)*num_bms),1)];
        column=column(randperm(num_bms));
        V_binary_matrix(:,k)=column;     
    end
    in= sum(V_binary_matrix,2)==0;  %%% check the rows with all zeros
    V_binary_matrix(in,:)=[];       %%% eliminate the rows if the elements are all 0
    num_bms_2=size(V_binary_matrix,1);
    
    V_sampling(iter,:)=sum(V_binary_matrix);
    V_sampling_1(iter)=sum(V_sampling(iter,:)>0);  %%% record the number of the variables which can be sampled by WBMS
    nx=V_sampling_1(iter);
      

 %%%%%% calculate the regression coefficients
 num=1:Nx;
 B=V_binary_matrix;
 for i=1:num_bms_2  
         temp=V_binary_matrix(i,:); 
         del_X=temp==0;  
         V_X_new =Xcal;   
         V_X_new(:,del_X) = [];
         CV=plscvfold(V_X_new,ycal,A_max,fold,method);
         A_origin=CV.optPC;
         PLS=pls(V_X_new,ycal,A_origin,method); 
         position=num(V_binary_matrix(i,:)==1);
         for j=1:sum(V_binary_matrix(i,:))
         B(i,position(j))=PLS.coef_origin(j,A_origin);
         end
         B(i,:)=abs(B(i,:));
         B(i,:)=B(i,:)/max(B(i,:));  %%% normalizing the regression coefficients  
 end       
 

 %%%%%% calculate the criteria of the variables
 U=sum(abs(B));
 RI=U;  %%%% criteria of the variables
 [~,ranking]=sort(RI,'descend');    %%% rank the variables according to the criteria
 
 
 %%%%%% sequentially addition
 RMSECV=zeros(1,nx);
for j=1:nx
CV=plscvfold(Xcal(:,ranking(1:j)),ycal,A_max,fold,method,0);
RMSECV(j)=CV.RMSECV;
end
[va,index]=min(RMSECV);   %%% choose the variable subset with the lowest RMSECV value
RMSECV_min(iter)=va;
var_length(iter)=index;   %%% record the length of the variable subset
variables_coef{iter}=ranking(1:index);
Ranking(iter,1:index)=ranking(1:index);

 
 %%%%%  calculate the weights of the variables    
     weight=U/max(U);     
     Weight(iter,:)=weight; 
     
     
fprintf('The %dth IVSO round has finished,elapsed time is %g seconds!!\n',iter,toc);

 %%%%%%  stop the loop
if  nx==index 
     break
end

 end


 [~,I]=min(RMSECV_min);    %%% choose the best varibale subset with the lowest RMSECV value as the ultimate variable subset
  index_RMSECV_min=I;
 
 fprintf('The iterative rounds of IVSO have finished,elapsed time is %g seconds!!\n',toc);   
 F.iteration=iter;  %%% the number of the iterative rounds
 F.Sampling_number=V_sampling_1; %%% the number of the variables for sampling in each iterative round 
 F.minRMSECV=RMSECV_min;   %%% the RMSECV value of the chosen varibale subset
 F.Select_variables=variables_coef{I};  %%% the selected variables 
 F.nVar=var_length(I);   %%% the length of the selected variables
 F.Rank_variables=Ranking(I,1:var_length(I));  %%% the rank of the varibales in each iterative round
 F.Weight=Weight(1:iter-1,:);  %%%  % the weights for variables
 F.time=toc;
 